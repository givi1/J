 package org.example.demo;

 import javafx.fxml.FXML;
 import javafx.scene.chart.PieChart;
 import javafx.scene.control.TextField;

 import java.util.List;

public class HelloController {

    @FXML
    private TextField txt_name;

    @FXML
    private TextField txt_amount;

    @FXML
    private TextField txt_price;

    @FXML
    private PieChart pie_chart;

    private MySQLConnection mySQLConnection = new MySQLConnection();

    @FXML
    public void initialize() {
        reloadPieChart();
    }

    public void onAddButtonAction(){
        String name = txt_name.getText();
        int amount = Integer.parseInt(txt_amount.getText());
        int price = Integer.parseInt(txt_price.getText());
        Product product = new Product(0, name, amount, price);
        mySQLConnection.addProduct(product);
        txt_name.clear();
        txt_amount.clear();
        txt_price.clear();
        reloadPieChart();
    }

    private void reloadPieChart() {
        pie_chart.getData().clear();
        List<Product> products = mySQLConnection.getProducts();
        pie_chart.getData().addAll(products.stream().map(product -> new PieChart.Data(product.getName(), product.getAmount())).toList());
    }
}

