

package org.example.demo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class MySQLConnection {

    private Connection connection;

    public MySQLConnection() {
        connection = connectDb();
    }

    public void addProduct(Product product) {
        String sql = "INSERT INTO product (name, amount, price) VALUES(?,?,?)";
        try{
            PreparedStatement pst = connection.prepareStatement(sql);
            pst.setString(1, product.getName());
            pst.setInt(2, product.getAmount());
            pst.setInt(3, product.getPrice());
            pst.execute();

            JOptionPane.showMessageDialog(null, "Product added successfully");;
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }

    public List<Product> getProducts() {
        List<Product> list = new ArrayList<>();
        try {
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM product");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Product(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("amount"),
                        rs.getInt("price")
                ));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return list;
    }

    private Connection connectDb(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/products", "root", "");
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
}


